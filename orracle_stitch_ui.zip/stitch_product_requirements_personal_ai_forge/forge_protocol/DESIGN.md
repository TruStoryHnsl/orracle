# Design System Specification: The Kinetic Forge

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Tectonic"**
This design system moves beyond the "flat dashboard" trope to create a high-performance environment that feels like a precision instrument. It rejects the generic "SaaS-blue" aesthetic in favor of a rigid, brutalist structure infused with high-frequency data density. 

The system achieves an "Editorial-Technical" hybrid look by utilizing **intentional asymmetry**—offsetting heavy data tables with expansive, airy mono-spaced labels—and **tonal depth**. Instead of using lines to separate complex AI parameters, we use shifting depths of charcoal and obsidian to create a UI that feels carved from a single block of silicon.

---

## 2. Colors & Surface Architecture
The palette is rooted in a "Deep Space" philosophy. Backgrounds are not black, but a sophisticated `#131313` charcoal, allowing vibrant cyan data points to "pop" with optical vibrance.

### The "No-Line" Rule
**Strict Mandate:** 1px solid borders are prohibited for sectioning. Structural definition must be achieved through:
- **Tonal Stepping:** Use `surface_container_low` against `surface` to define a sidebar.
- **Negative Space:** Use the `Spacing Scale (8, 10, 12)` to create logical groupings.
- **Luminance Shifts:** A `surface_container_highest` header sitting on a `surface_dim` body provides all the "edge" a user needs without visual clutter.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack. Each "level" of the AI Forge logic should sit on a specific tier:
- **Base Layer:** `surface` (#131313) – The primary workspace.
- **Input Zones:** `surface_container_low` (#1c1b1b) – Slightly elevated for focus.
- **Floating Controls/Modals:** `surface_container_high` (#2a2a2a) with a 12px `backdrop-blur` to create a "Glassmorphism" effect that maintains the IDE aesthetic.

### Signature Textures
Main CTAs and critical progress indicators should utilize a **Horizontal Kinetic Gradient**:
- From `primary` (#00daf3) to `primary_container` (#009fb2). This creates a sense of forward motion and "energy" within the forge.

---

## 3. Typography
The system employs a high-contrast pairing: **Space Grotesk** (Tech-Industrial) for headers and **Inter** (High-Legibility) for data.

- **Display & Headlines (Space Grotesk):** Use `display-lg` and `headline-md` to anchor the page. These should be set with tight letter-spacing (-0.02em) to feel authoritative and engineered.
- **The Technical Layer (Mono-Logic):** All hardware specs, node IDs, and code snippets must use a monospace font (fallback: JetBrains Mono) at `label-sm` or `body-sm` sizes. This separates "Human Narrative" from "Machine Data."
- **Data Density:** Use `label-md` for table headers. The small, uppercase monospace look provides a high-density "mission control" feel without exhausting the eye.

---

## 4. Elevation & Depth
In a high-performance IDE, traditional drop shadows feel "mushy." We use **Ambient Occlusion** logic.

- **The Layering Principle:** Depth is achieved by stacking. A `surface_container_lowest` (#0e0e0e) card placed on a `surface` background creates a "recessed" look, perfect for terminal outputs.
- **Ghost Borders:** If a container needs an edge (e.g., a hovering tooltip), use `outline_variant` (#414755) at **15% opacity**. It should be felt, not seen.
- **Atmospheric Blur:** For overlays, use a `surface_variant` tint with a 20px blur. This keeps the user grounded in the "Forge" context while focusing on the temporary task.

---

## 5. Components

### Buttons
- **Primary:** `primary` (#00daf3) background with `on_primary` (#00363d) text. 0px corner radius. No border.
- **Secondary (The Technical Button):** `outline` (#8b90a0) at 20% opacity background. On hover, transition to `secondary_container` (#4b8eff).
- **State Logic:** Active nodes use `tertiary` (#48ddbc) "Emerald" pulses. Busy nodes use an `amber` (Custom Token) glow.

### High-Density Data Tables
- **Grid:** Forbid vertical dividers. Use `surface_container_low` for zebra-striping on hover.
- **Alignment:** Numbers and Monospace data should be tabular-lining (monospaced numbers) to ensure columns align perfectly for rapid scanning.

### Progress Bars (Real-Time Feedback)
- **Track:** `surface_container_highest`.
- **Indicator:** A gradient of `primary` to `tertiary`. For "Busy" states, apply a CSS shimmer animation to the gradient to indicate active computation.

### Input Fields & Parameter Controls
- **Styling:** Recessed look using `surface_container_lowest`. 
- **Focus State:** No glow. Instead, use a 2px `primary` solid bottom-border to signal an "Active Terminal" state.
- **Collapsible Sidebars:** Use `surface_container_low`. When collapsed, only `label-sm` monospace icons should remain, rotated 90 degrees for a custom "blueprint" feel.

---

## 6. Do’s and Don’ts

### Do
- **Do** use `0px` border-radius for everything. The system is built on precision and "hard" engineering.
- **Do** lean into `surface` shifts. If a section feels messy, try making the background one shade darker (`surface_container_lowest`) rather than adding a border.
- **Do** use `primary_fixed_dim` for non-interactive data highlights to avoid over-stimulating the user.

### Don't
- **Don't** use standard "drop shadows." They break the technical, flat-surface aesthetic of the Forge.
- **Don't** use rounded corners. Even a 2px radius will soften the "High-Performance" intent and make it look like a standard consumer app.
- **Don't** use dividers between list items. Use 0.4rem (`2`) of vertical padding to let the eye create its own boundaries.
- **Don't** use pure white (#ffffff). It causes "haloing" on dark backgrounds. Always use `on_surface` (#e5e2e1) for text.